@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    gradle %*
    exit /b %ERRORLEVEL%
)
echo Gradle 8.7 is required. Install it or open this project in Android Studio.
exit /b 1
