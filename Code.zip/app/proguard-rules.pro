# JarvisMohsinCore currently relies on standard Android/Retrofit APIs.
# Add project-specific R8 rules here if future reflection-based libraries require them.
