package com.mohsin.jarvis.ui

import android.content.Intent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.mohsin.jarvis.service.WakeWordService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.mohsin.jarvis.network.ChatRequest
import com.mohsin.jarvis.network.NetworkModule
import android.speech.tts.TextToSpeech
import java.util.Locale

object JarvisOverlay {
    var rms by mutableFloatStateOf(0f)
    var voicePrompt by mutableStateOf("")
    var voiceSubmitNonce by mutableIntStateOf(0)
}

@Composable
fun JarvisOverlay(service: WakeWordService, initialRms: Float) {
    val scope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("") }

    LaunchedEffect(JarvisOverlay.voicePrompt) {
        if (JarvisOverlay.voicePrompt.isNotBlank()) {
            prompt = JarvisOverlay.voicePrompt
        }
    }
    var answer by remember { mutableStateOf("Listening…") }

    fun sendPrompt(value: String) {
        val p = value.trim()
        if (p.isEmpty()) return
        answer = "Thinking…"
        scope.launch(Dispatchers.IO) {
            runCatching { NetworkModule.api.chat(ChatRequest(p)).textValue() }
                .onSuccess { text ->
                    scope.launch(Dispatchers.Main) {
                        answer = text
                        tts.language = Locale.US
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
                    }
                }
                .onFailure { e ->
                    scope.launch(Dispatchers.Main) {
                        answer = "Network error: ${e.message ?: "unknown"}"
                    }
                }
        }
    }

    LaunchedEffect(JarvisOverlay.voiceSubmitNonce) {
        if (JarvisOverlay.voiceSubmitNonce > 0) {
            sendPrompt(JarvisOverlay.voicePrompt)
        }
    }
    val pulse = rememberInfiniteTransition(label = "idle")
    val idle by pulse.animateFloat(0.96f, 1.04f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "pulse")
    val tts = remember { TextToSpeech(service) { } }
    DisposableEffect(Unit) { onDispose { tts.stop(); tts.shutdown() } }

    Surface(
        modifier = Modifier.fillMaxWidth().padding(8.dp),
        shape = RoundedCornerShape(32.dp),
        color = Color(0xDD020814),
        tonalElevation = 20.dp
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(20.dp)) {
            Box(Modifier.size(230.dp).blur(2.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2, size.height / 2)
                    val level = JarvisOverlay.rms
                    val base = size.minDimension * 0.22f * idle
                    drawCircle(Brush.radialGradient(listOf(Color(0xFF00FFFF), Color(0xFF0088FF), Color(0xFF0044FF), Color.Transparent), center, base * 2.2f), center, base * 2.2f)
                    repeat(5) { i ->
                        val radius = base + i * 17f + level * (i + 1) * 11f
                        drawCircle(Color(0x6600FFFF), center, radius, style = Stroke(width = 2.5f + level * 3f))
                    }
                    drawCircle(Color(0xFF00FFFF), center, base * (0.78f + level * 0.16f))
                    drawCircle(Brush.radialGradient(listOf(Color.White, Color(0xFF00FFFF), Color(0xFF0044FF)), Offset(center.x - base * .25f, center.y - base * .35f), base), center, base * .72f)
                }
            }
            Text("JARVIS", color = Color(0xFF00FFFF), style = MaterialTheme.typography.headlineSmall)
            Text(answer, color = Color.White.copy(alpha = .85f), modifier = Modifier.padding(8.dp))
            OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text("Voice / text command") }, singleLine = false)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(modifier = Modifier.weight(1f), onClick = { sendPrompt(prompt) }) { Text("Send") }
                TextButton(onClick = { service.startActivity(Intent(service, PickerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("📎") }
                TextButton(onClick = { service.dismissOverlay() }) { Text("Close") }
            }
        }
    }
}
