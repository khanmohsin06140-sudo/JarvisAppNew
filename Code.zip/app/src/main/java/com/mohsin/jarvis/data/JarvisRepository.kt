package com.mohsin.jarvis.data

import com.mohsin.jarvis.network.ChatRequest
import com.mohsin.jarvis.network.JarvisApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

class JarvisRepository(private val api: JarvisApi) {

    suspend fun sendMessage(message: String, conversationId: String? = null): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val response = api.chat(ChatRequest(message, conversationId))
                if (!response.isSuccessful) {
                    throw IllegalStateException("Backend returned HTTP ${response.code()}")
                }
                val body = response.body()?.string().orEmpty()
                if (body.isBlank()) throw IllegalStateException("Backend returned an empty response")
                parseReply(body)
            }
        }

    private fun parseReply(body: String): String {
        return try {
            val json = JSONObject(body)
            listOf("reply", "response", "message", "text")
                .firstNotNullOfOrNull { key ->
                    json.optString(key, "").takeIf { it.isNotBlank() }
                } ?: body
        } catch (_: Exception) {
            body
        }
    }
}
