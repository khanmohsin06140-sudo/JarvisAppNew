package com.mohsin.jarvis.network

import retrofit2.http.Body
import retrofit2.http.POST

data class ChatRequest(val message: String, val sessionId: String? = null)
data class ChatResponse(val response: String? = null, val message: String? = null, val text: String? = null) {
    fun textValue(): String = response ?: message ?: text ?: "I did not receive a response."
}

interface JarvisApi {
    @POST("api/chat")
    suspend fun chat(@Body request: ChatRequest): ChatResponse
}
