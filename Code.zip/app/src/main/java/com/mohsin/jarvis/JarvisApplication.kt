package com.mohsin.jarvis

import android.app.Application
import com.mohsin.jarvis.data.JarvisRepository
import com.mohsin.jarvis.network.NetworkModule
import com.mohsin.jarvis.voice.SpeechManager

class JarvisApplication : Application() {
    val repository: JarvisRepository by lazy {
        JarvisRepository(NetworkModule.api)
    }

    val speechManager: SpeechManager by lazy {
        SpeechManager(this)
    }
}
