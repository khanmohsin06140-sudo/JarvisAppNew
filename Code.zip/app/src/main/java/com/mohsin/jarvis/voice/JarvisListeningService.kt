package com.mohsin.jarvis.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.mohsin.jarvis.R

class JarvisListeningService : Service() {
    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel("jarvis_mic", "JARVIS microphone", NotificationManager.IMPORTANCE_LOW)
        )
        val notification: Notification = NotificationCompat.Builder(this, "jarvis_mic")
            .setSmallIcon(R.drawable.ic_jarvis)
            .setContentTitle("JARVIS")
            .setContentText("Microphone service active")
            .setOngoing(true)
            .build()
        startForeground(42, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
