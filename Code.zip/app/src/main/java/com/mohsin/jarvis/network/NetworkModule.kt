package com.mohsin.jarvis.network

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.Response
import okhttp3.ResponseBody
import java.util.concurrent.TimeUnit

data class ChatRequest(
    val message: String,
    val conversationId: String? = null
)

interface JarvisApi {
    @POST("api/chat")
    suspend fun chat(@Body request: ChatRequest): Response<ResponseBody>
}

object NetworkModule {
    private val logging = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(logging)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    val api: JarvisApi = Retrofit.Builder()
        .baseUrl("https://jarvis-backend-6c1r.onrender.com/")
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(JarvisApi::class.java)
}
