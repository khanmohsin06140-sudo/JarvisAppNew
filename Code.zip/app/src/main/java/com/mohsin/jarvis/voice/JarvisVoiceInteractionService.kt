package com.mohsin.jarvis.voice

import android.service.voice.VoiceInteractionService

class JarvisVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
        // Android calls this when the service is active as the selected voice assistant.
    }

    override fun onShutdown() {
        super.onShutdown()
    }
}
