package com.mohsin.jarvis.service

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.speech.*
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.mohsin.jarvis.ui.JarvisOverlay

class WakeWordService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var overlay: ComposeView? = null
    private var overlayOwner: OverlayOwner? = null
    private var windowManager: WindowManager? = null
    private var rms = 0f

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(77, notification(), ServiceInfoCompat.microphoneType())
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            setupRecognizer()
            startListening()
        }
    }

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { listening = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) { rms = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f); JarvisOverlay.rms = rms }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false }
                override fun onError(error: Int) {
                    listening = false
                    if (error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || error == SpeechRecognizer.ERROR_NO_MATCH) { restartListening() } else restartListening()
                }
                override fun onResults(results: Bundle?) {
                    listening = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    if (matches.any { it.lowercase().contains("hey jarvis") || it.lowercase().contains("jarvis") }) {
                        handler.post { showOverlay() }
                    } else restartListening()
                }
                override fun onPartialResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    if (matches.any { it.lowercase().contains("hey jarvis") || it.lowercase().contains("jarvis") }) handler.post { showOverlay() }
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun startListening() {
        handler.post {
            if (recognizer == null || listening || overlay != null) return@post
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            runCatching { recognizer?.startListening(intent); listening = true }
        }
    }

    private fun restartListening() { handler.post { if (overlay == null) { listening = false; startListening() } } }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this) || overlay != null) { restartListening(); return }
        recognizer?.cancel(); listening = false
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayOwner = OverlayOwner().also { it.create() }
        val view = ComposeView(this).also {
            it.setViewTreeLifecycleOwner(overlayOwner)
            it.setViewTreeViewModelStoreOwner(overlayOwner)
            it.setViewTreeSavedStateRegistryOwner(overlayOwner)
            it.setContent { JarvisOverlay(service = this@WakeWordService, initialRms = rms) }
        }
        overlay = view
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.90f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        // OverlayOwner is already RESUMED before addView(), preventing ViewTreeLifecycleOwner crashes.
        windowManager?.addView(view, params)
    }

    fun dismissOverlay() {
        handler.post {
            overlay?.let { runCatching { windowManager?.removeView(it) } }
            overlay = null
            overlayOwner?.destroy(); overlayOwner = null
            restartListening()
        }
    }

    fun rmsValue(): Float = rms

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        overlay?.let { view -> runCatching { windowManager?.removeView(view) } }
        overlay = null
        overlayOwner?.destroy()
        overlayOwner = null
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    private fun notification(): Notification = NotificationCompat.Builder(this, "jarvis_wake")
        .setContentTitle("JarvisMohsinCore")
        .setContentText("Listening for Hey Jarvis")
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setOngoing(true).build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("jarvis_wake", "Jarvis microphone", NotificationManager.IMPORTANCE_LOW))
        }
    }
}

private object ServiceInfoCompat {
    fun microphoneType(): Int = if (Build.VERSION.SDK_INT >= 29) android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
}
