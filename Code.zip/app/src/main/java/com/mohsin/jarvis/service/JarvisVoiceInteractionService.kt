package com.mohsin.jarvis.service

import android.service.voice.VoiceInteractionService

class JarvisVoiceInteractionService : VoiceInteractionService()
