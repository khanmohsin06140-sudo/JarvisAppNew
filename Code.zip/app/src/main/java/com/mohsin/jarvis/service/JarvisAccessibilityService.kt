package com.mohsin.jarvis.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        val text = collectText(root).trim()
        // Boilerplate parser: commands can be supplied by the AI as JSON, e.g. {"action":"open_app","package":"com.android.settings"}.
        parseAndExecute(text)
    }

    private fun collectText(node: AccessibilityNodeInfo): String {
        val out = StringBuilder()
        node.text?.let { out.append(it).append(' ') }
        for (i in 0 until node.childCount) node.getChild(i)?.let { out.append(collectText(it)); it.recycle() }
        return out.toString()
    }

    fun parseAndExecute(json: String) {
        val action = Regex("\"action\"\s*:\s*\"([^\"]+)\"").find(json)?.groupValues?.getOrNull(1) ?: return
        if (action == "open_app") {
            val pkg = Regex("\"package\"\s*:\s*\"([^\"]+)\"").find(json)?.groupValues?.getOrNull(1) ?: return
            packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }
    override fun onInterrupt() {}
}
