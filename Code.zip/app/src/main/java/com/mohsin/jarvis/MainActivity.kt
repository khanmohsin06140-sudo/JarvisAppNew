package com.mohsin.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.mohsin.jarvis.service.WakeWordService

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
        setContent {
            MaterialTheme {
                Surface {
                    Column {
                        Text("JarvisMohsinCore", style = MaterialTheme.typography.headlineMedium)
                        Button(onClick = {
                            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                            else ContextCompat.startForegroundService(this, Intent(this, WakeWordService::class.java))
                        }) { Text("Start Hey Jarvis") }
                    }
                }
            }
        }
    }
}
