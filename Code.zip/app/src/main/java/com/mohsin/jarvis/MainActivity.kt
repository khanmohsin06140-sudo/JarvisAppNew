package com.mohsin.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.mohsin.jarvis.ui.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: JarvisViewModel by viewModels {
        JarvisViewModelFactory((application as JarvisApplication).repository)
    }

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { vm.setState(AssistantState.IDLE) }

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JarvisTheme {
                JarvisApp(
                    vm = vm,
                    requestMic = {
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                            PackageManager.PERMISSION_GRANTED) {
                            vm.setState(AssistantState.LISTENING)
                            (application as JarvisApplication).speechManager.startListening(
                                onState = { state ->
                                    when (state) {
                                        is com.mohsin.jarvis.voice.SpeechState.Listening -> vm.setState(AssistantState.LISTENING)
                                        is com.mohsin.jarvis.voice.SpeechState.Error -> vm.setState(AssistantState.ERROR)
                                        com.mohsin.jarvis.voice.SpeechState.Idle -> Unit
                                    }
                                },
                                onText = { vm.send(it) }
                            )
                        } else {
                            micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    openAccessibility = {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    },
                    openAssistant = {
                        if (Build.VERSION.SDK_INT >= 29) {
                            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
                        }
                    },
                    requestNotifications = {
                        if (Build.VERSION.SDK_INT >= 33) {
                            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        (application as JarvisApplication).speechManager.destroy()
        super.onDestroy()
    }
}

@Composable
private fun JarvisTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        background = Color.Black,
        surface = Color(0xFF05090B),
        primary = Color(0xFF00FFFF),
        onPrimary = Color.Black,
        secondary = Color(0xFF00FFFF),
        onBackground = Color(0xFFE8FFFF),
        onSurface = Color(0xFFE8FFFF)
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@Composable
private fun JarvisApp(
    vm: JarvisViewModel,
    requestMic: () -> Unit,
    openAccessibility: () -> Unit,
    openAssistant: () -> Unit,
    requestNotifications: () -> Unit
) {
    val ui by vm.ui.collectAsState()
    var text by remember { mutableStateOf("") }
    var showDiagnostics by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(ui.messages.size) {
        if (ui.messages.isNotEmpty()) scope.launch {
            listState.animateScrollToItem(ui.messages.lastIndex)
        }
    }

    if (showDiagnostics) {
        DiagnosticsScreen(
            onBack = { showDiagnostics = false },
            openAccessibility = openAccessibility,
            openAssistant = openAssistant,
            requestMic = requestMic,
            requestNotifications = requestNotifications
        )
        return
    }

    Scaffold(
        containerColor = Color.Black,
        topBar = {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("JARVIS", color = Color(0xFF00FFFF), fontWeight = FontWeight.Bold)
                    Text("MOHSIN AI CORE", style = MaterialTheme.typography.labelSmall)
                }
                TextButton(onClick = { showDiagnostics = true }) {
                    Text("DIAGNOSTICS")
                }
            }
        },
        bottomBar = {
            Row(
                Modifier.fillMaxWidth().padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Talk to JARVIS...") },
                    singleLine = true
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    vm.send(text)
                    text = ""
                }) { Text("SEND") }
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            JarvisOrb(ui.state)
            Text(
                text = when (ui.state) {
                    AssistantState.IDLE -> "SYSTEM ONLINE"
                    AssistantState.LISTENING -> "LISTENING..."
                    AssistantState.PROCESSING -> "PROCESSING..."
                    AssistantState.SPEAKING -> "SPEAKING..."
                    AssistantState.ERROR -> "ERROR"
                },
                color = Color(0xFF00FFFF),
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(12.dp))

            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 12.dp)
            ) {
                items(ui.messages) { message ->
                    MessageBubble(message)
                }
                ui.error?.let { error ->
                    item {
                        Text("Network: $error", color = Color(0xFFFF6B6B))
                    }
                }
            }

            Button(
                onClick = requestMic,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FFFF), contentColor = Color.Black)
            ) {
                Text("MICROPHONE")
            }
        }
    }
}

@Composable
private fun JarvisOrb(state: AssistantState) {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = if (state == AssistantState.LISTENING) 1.15f else 1.04f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulse"
    )
    Box(
        Modifier.size(190.dp).scale(pulse).border(2.dp, Color(0xFF00FFFF), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(140.dp).border(2.dp, Color(0xFF00FFFF), CircleShape).alpha(0.65f),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(80.dp).background(Color(0xFF00FFFF), CircleShape).alpha(0.18f))
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (message.fromUser) Color(0xFF062326) else Color(0xFF071013),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00FFFF).copy(alpha = 0.25f))
        ) {
            Column(Modifier.padding(12.dp).widthIn(max = 320.dp)) {
                Text(message.text)
                Text(message.time, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            }
        }
    }
}

@Composable
private fun DiagnosticsScreen(
    onBack: () -> Unit,
    openAccessibility: () -> Unit,
    openAssistant: () -> Unit,
    requestMic: () -> Unit,
    requestNotifications: () -> Unit
) {
    val context = LocalContext.current
    val mic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED
    val notifications = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
        PackageManager.PERMISSION_GRANTED
    val accessibility = Settings.Secure.getString(
        context.contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    )?.contains(context.packageName) == true

    Column(Modifier.fillMaxSize().background(Color.Black).padding(18.dp)) {
        TextButton(onClick = onBack) { Text("← BACK") }
        Text("PERMISSIONS DIAGNOSTICS", style = MaterialTheme.typography.headlineSmall, color = Color(0xFF00FFFF))
        Spacer(Modifier.height(18.dp))

        DiagnosticRow("Microphone", if (mic) "GRANTED" else "DENIED") {
            if (!mic) requestMic()
        }
        DiagnosticRow("Notifications", if (notifications) "GRANTED" else "DENIED") {
            if (!notifications) requestNotifications()
        }
        DiagnosticRow("Accessibility Service", if (accessibility) "ACTIVE" else "INACTIVE") {
            if (!accessibility) openAccessibility()
        }
        DiagnosticRow("Default Assistant", "CHECK IN SYSTEM SETTINGS") {
            openAssistant()
        }

        Spacer(Modifier.height(18.dp))
        Text(
            "Android controls assistant selection and accessibility access. JARVIS only uses APIs that the OS exposes after explicit user enablement.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun DiagnosticRow(label: String, status: String, action: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, fontWeight = FontWeight.Bold)
            Text(status, color = Color(0xFF00FFFF))
        }
        OutlinedButton(onClick = action) { Text("OPEN") }
    }
}
