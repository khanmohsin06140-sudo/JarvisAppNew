package com.mohsin.jarvis.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mohsin.jarvis.data.JarvisRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class AssistantState { IDLE, LISTENING, PROCESSING, SPEAKING, ERROR }

data class ChatMessage(
    val text: String,
    val fromUser: Boolean,
    val time: String
)

data class JarvisUiState(
    val state: AssistantState = AssistantState.IDLE,
    val messages: List<ChatMessage> = emptyList(),
    val error: String? = null
)

class JarvisViewModel(private val repository: JarvisRepository) : ViewModel() {
    private val _ui = MutableStateFlow(JarvisUiState())
    val ui: StateFlow<JarvisUiState> = _ui.asStateFlow()

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val now = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        _ui.value = _ui.value.copy(
            state = AssistantState.PROCESSING,
            error = null,
            messages = _ui.value.messages + ChatMessage(clean, true, now)
        )
        viewModelScope.launch {
            repository.sendMessage(clean).fold(
                onSuccess = { reply ->
                    val time = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
                    _ui.value = _ui.value.copy(
                        state = AssistantState.IDLE,
                        messages = _ui.value.messages + ChatMessage(reply, false, time)
                    )
                },
                onFailure = { error ->
                    _ui.value = _ui.value.copy(
                        state = AssistantState.ERROR,
                        error = error.message ?: "Network error"
                    )
                }
            )
        }
    }

    fun setState(state: AssistantState) {
        _ui.value = _ui.value.copy(state = state, error = if (state != AssistantState.ERROR) null else _ui.value.error)
    }
}

class JarvisViewModelFactory(private val repository: JarvisRepository) :
    androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return JarvisViewModel(repository) as T
    }
}
