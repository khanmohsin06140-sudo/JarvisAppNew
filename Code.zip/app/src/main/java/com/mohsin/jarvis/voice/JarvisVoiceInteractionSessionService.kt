package com.mohsin.jarvis.voice

import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService

class JarvisVoiceInteractionSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: android.os.Bundle?): VoiceInteractionSession {
        return JarvisVoiceInteractionSession(this)
    }
}

private class JarvisVoiceInteractionSession(
    service: VoiceInteractionSessionService
) : VoiceInteractionSession(service) {
    override fun onShow(args: android.os.Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        // The main Compose UI remains the primary assistant surface.
        // This session intentionally avoids claiming restricted system control.
    }
}
