package com.mohsin.jarvis.ui

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect

class PickerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
                // Production app can upload this URI as multipart data; the core attachment flow is wired here.
                setResult(if (uri != null) RESULT_OK else RESULT_CANCELED, intent.apply { data = uri })
                finish()
            }
            LaunchedEffect(Unit) { picker.launch("image/*") }
            Text("Selecting image…")
        }
    }
}
