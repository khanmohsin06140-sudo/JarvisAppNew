package com.mohsin.jarvis

import android.service.voice.VoiceInteractionService

class JarvisVoiceInteractionService : VoiceInteractionService()
