package com.mohsin.jarvis

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Button(onClick = {
                        if (android.os.Build.VERSION.SDK_INT >= 26)
                            startForegroundService(Intent(this@MainActivity, WakeWordService::class.java))
                        else startService(Intent(this@MainActivity, WakeWordService::class.java))
                    }) { Text("Start Hey Jarvis") }
                }
            }
        }
    }
}
