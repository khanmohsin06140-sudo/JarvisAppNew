package com.mohsin.jarvis

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.os.*
import android.speech.*
import android.view.*
import android.widget.*
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewTreeLifecycleOwner
import androidx.compose.ui.platform.ViewTreeViewModelStoreOwner
import androidx.savedstate.*
import androidx.lifecycle.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.dp
import androidx.compose.material3.*
import kotlin.math.max
import kotlin.math.min

class WakeWordService : Service() {
    private lateinit var recognizer: SpeechRecognizer
    private val handler = Handler(Looper.getMainLooper())
    private var rms = 0f

    override fun onCreate() {
        super.onCreate()
        startForeground(7, notification())
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) { rms = ((v + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { restart() }
            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                    error == SpeechRecognizer.ERROR_NO_MATCH) restart()
                else restart()
            }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                if (matches.any { it.contains("hey jarvis", true) || it.contains("jarvis", true) })
                    showOverlay()
                restart()
            }
            override fun onPartialResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                if (matches.any { it.contains("hey jarvis", true) }) showOverlay()
            }
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        startListening()
    }

    private fun restart() {
        handler.post { startListening() }
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { recognizer.startListening(intent) } catch (_: Exception) { handler.postDelayed({ startListening() }, 250) }
    }

    private fun notification(): Notification {
        val channel = "jarvis"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(channel, "Jarvis", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, channel).setContentTitle("JarvisMohsinCore")
            .setContentText("Listening for Hey Jarvis").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
    }

    private fun showOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val compose = ComposeView(this)
        val lifecycleOwner = object : LifecycleOwner { val registry = LifecycleRegistry(this); override val lifecycle = registry }
        val vmOwner = object : ViewModelStoreOwner { override val viewModelStore = ViewModelStore() }
        val savedOwner = object : SavedStateRegistryOwner {
            override val lifecycle: Lifecycle = lifecycleOwner.lifecycle
            override val savedStateRegistry = SavedStateRegistryController.create(this).savedStateRegistry
        }
        ViewTreeLifecycleOwner.set(compose, lifecycleOwner)
        ViewTreeViewModelStoreOwner.set(compose, vmOwner)
        compose.setViewTreeSavedStateRegistryOwner(savedOwner)
        (lifecycleOwner.lifecycle as LifecycleRegistry).currentState = Lifecycle.State.RESUMED

        compose.setContent { JarvisOverlay() }
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * .92).toInt(), (resources.displayMetrics.heightPixels * .68).toInt(),
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.CENTER
        wm.addView(compose, params)
    }

    override fun onBind(intent: Intent?) = null
}

@Composable
fun JarvisOverlay() {
    var prompt by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("Awaiting command…") }
    var attached by remember { mutableStateOf("") }
    val idle = rememberInfiniteTransition(label = "idle")
    val pulse by idle.animateFloat(0.96f, 1.05f, androidx.compose.animation.core.infiniteRepeatable(
        androidx.compose.animation.core.tween(1400), androidx.compose.animation.core.RepeatMode.Reverse), label = "pulse")
    Box(Modifier.fillMaxSize().background(Color(0xFF020816))) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension * .20f * pulse
            drawCircle(Brush.radialGradient(listOf(Color(0xFF00FFFF), Color(0xFF0088FF), Color(0x000044FF)), c, r), c, r)
            for (i in 1..5) drawCircle(Color(0xFF00FFFF).copy(alpha=.16f/i), c, r + i*24.dp.toPx(), style=androidx.compose.ui.graphics.drawscope.Stroke(width=4f))
        }
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Bottom) {
            Text("JARVIS", color=Color(0xFF00FFFF), style=MaterialTheme.typography.headlineMedium)
            Text(reply, color=Color.White, modifier=Modifier.padding(vertical=12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(prompt, { prompt = it }, Modifier.weight(1f), label={Text("Command")})
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    Thread {
                        try {
                            val res = kotlinx.coroutines.runBlocking { NetworkModule.api.chat(ChatRequest(prompt)) }
                            reply = res.response ?: res.text ?: "No response"
                        } catch (e: Exception) { reply = "Connection error: ${e.message}" }
                    }.start()
                }) { Text("Send") }
            }
        }
    }
}
