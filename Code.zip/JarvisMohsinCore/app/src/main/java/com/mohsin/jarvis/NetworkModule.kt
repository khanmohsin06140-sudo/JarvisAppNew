package com.mohsin.jarvis

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

data class ChatRequest(val message: String)
data class ChatResponse(val response: String? = null, val text: String? = null, val action: String? = null)

interface JarvisApi {
    @POST("api/chat")
    suspend fun chat(@Body request: ChatRequest): ChatResponse
}

object NetworkModule {
    val api: JarvisApi = Retrofit.Builder()
        .baseUrl("https://jarvis-backend-6c1r.onrender.com/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(JarvisApi::class.java)
}
