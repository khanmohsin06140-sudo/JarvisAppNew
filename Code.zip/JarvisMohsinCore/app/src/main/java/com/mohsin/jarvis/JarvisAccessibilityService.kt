package com.mohsin.jarvis

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.content.Intent

class JarvisAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        val text = root.findAccessibilityNodeInfosByText("open_app").firstOrNull()?.text?.toString()
        if (text == "open_app") { /* Backend command execution hook. */ }
    }
    override fun onInterrupt() {}
}
