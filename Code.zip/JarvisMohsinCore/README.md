# JarvisMohsinCore
Production-oriented Android starter for a voice-first Jarvis overlay.

Build:
./gradlew assembleDebug

Gradle wrapper distribution: 8.7
Backend base URL: https://jarvis-backend-6c1r.onrender.com/
