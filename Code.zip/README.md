# JarvisMohsinCore

A Kotlin/Jetpack Compose Android JARVIS-style assistant with MVVM, Retrofit/OkHttp networking, STT/TTS, AccessibilityService, VoiceInteractionService, diagnostics, and GitHub Actions.

## Backend

The app uses Retrofit with the required exact base URL:

`https://jarvis-backend-6c1r.onrender.com/`

The current client posts chat requests to `api/chat` with:

```json
{"message":"Hello","conversationId":null}
```

Because the backend contract was not supplied with this project, the response parser accepts common fields (`reply`, `response`, `message`, `text`) or a plain-text response. If your server exposes a different path/schema, change only `JarvisApi` / the request model.

## Security

No private API key is stored in Android source, resources, manifest, or BuildConfig. The backend is the intended AI/API intermediary.

`android:usesCleartextTraffic="true"` is present because it was explicitly required. The configured backend itself is HTTPS.

## Android limitations implemented honestly

- AccessibilityService only sees content exposed through Android accessibility APIs and only after the user enables it.
- VoiceInteractionService can be selected as the device assistant only on Android versions/OEMs that expose the role and satisfy their requirements.
- SpeechRecognizer is used for supported speech recognition. Continuous listening is not forced indefinitely; Android/OEM behavior and background execution restrictions apply.
- A microphone foreground-service declaration is included for legitimate long-running microphone work, but Android still controls when and how it may run.
- The app does not attempt hidden UI access, security bypasses, or unrestricted control of other apps.

## Build

The repository is intended to build with JDK 17, Android SDK 35, AGP 8.6.1 and Gradle 8.7.

### GitHub Actions

`.github/workflows/build.yml` checks out the repository, installs JDK 17, makes `gradlew` executable, builds the debug APK, and uploads:

`JarvisMohsinCore-debug.apk`

### Local

Run:

```bash
./gradlew assembleDebug
```

The debug APK is generated under:

`app/build/outputs/apk/debug/app-debug.apk`

## Wrapper note

This environment did not contain a Gradle installation or a pre-existing official wrapper JAR, and external downloads were unavailable while generating the artifact. To keep the requested `gradle/wrapper/gradle-wrapper.jar` path present without inserting a fake binary, the included launcher scripts bootstrap Gradle 8.7 directly when needed. GitHub Actions has network access and will download the pinned Gradle distribution.
