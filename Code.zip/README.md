# JarvisMohsinCore

Production-oriented Android/Kotlin Jetpack Compose starter for a Jarvis-style assistant.

## Build

- Android Studio
- JDK 17
- Gradle 8.7
- compileSdk 35 / targetSdk 35

GitHub Actions uses Java 17 and Gradle 8.7 explicitly.

## Required permissions

Microphone permission and draw-over-other-apps permission must be granted by the user before the wake-word foreground service can operate.

## Backend

The Retrofit base URL is exactly:
`https://jarvis-backend-6c1r.onrender.com/`

Chat endpoint: `POST api/chat`.
