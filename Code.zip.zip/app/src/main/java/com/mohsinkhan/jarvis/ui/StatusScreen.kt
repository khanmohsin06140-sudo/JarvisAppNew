package com.mohsinkhan.jarvis.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

@Composable
fun StatusScreen(onClose: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSpace)
            .padding(24.dp)
    ) {
        Text("JARVIS PERMISSION DIAGNOSTICS", color = NeonCyan, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(24.dp))

        // In a live environment, these status strings evaluate real OS states via Accompanist.
        StatusRow("Microphone:", "GRANTED", true)
        StatusRow("Notifications:", "GRANTED", true)
        StatusRow("Accessibility Service:", "NOT CONNECTED", false)
        StatusRow("Assistant Role:", "INACTIVE", false)

        Spacer(modifier = Modifier.weight(1f))
        Button(
            onClick = onClose,
            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
        ) {
            Text("RETURN TO CORE", color = Color.White, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun StatusRow(title: String, status: String, isActive: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, color = Color.LightGray, fontFamily = FontFamily.Monospace)
        Text(
            status,
            color = if (isActive) NeonCyan else WarningRed,
            fontFamily = FontFamily.Monospace
        )
    }
}
