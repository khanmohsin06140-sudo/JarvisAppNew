package com.mohsinkhan.jarvis.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val DeepSpace = Color(0xFF030712)
val NeonCyan = Color(0xFF00F0FF)
val ElectricBlue = Color(0xFF0066FF)
val WarningRed = Color(0xFFFF3366)
val GlassPanel = Color(0x1A00F0FF)

@Composable
fun JarvisScreen(viewModel: JarvisViewModel) {
    val state by viewModel.currentState.collectAsState()
    val chatHistory by viewModel.chatHistory.collectAsState()
    var showStatusScreen by remember { mutableStateOf(false) }

    if (showStatusScreen) {
        StatusScreen(onClose = { showStatusScreen = false })
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSpace)
            .padding(16.dp)
    ) {
        TelemetryHeader(state, onStatusClick = { showStatusScreen = true })
        Spacer(modifier = Modifier.height(24.dp))

        Box(
            modifier = Modifier.fillMaxWidth().height(220.dp),
            contentAlignment = Alignment.Center
        ) {
            JarvisOrbAnimation(state)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Chat interface mirroring standard message orientation
        LazyColumn(
            modifier = Modifier.weight(1f),
            reverseLayout = true
        ) {
            items(chatHistory.reversed()) { message ->
                ChatBubble(message)
                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        MicrophoneInput(onQuerySubmitted = { viewModel.processBossQuery(it) })
    }
}

@Composable
fun TelemetryHeader(state: JarvisState, onStatusClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("JARVIS // CORE", color = NeonCyan, fontSize = 14.sp, fontFamily = FontFamily.Monospace)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = state.name,
                color = if (state == JarvisState.ERROR) WarningRed else ElectricBlue,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.width(16.dp))
            TextButton(onClick = onStatusClick) {
                Text("SYS_STATUS", color = NeonCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun JarvisOrbAnimation(state: JarvisState) {
    val transition = rememberInfiniteTransition(label = "jarvis_orb")

    val rotation by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    JarvisState.THINKING -> 600
                    JarvisState.EXECUTING -> 300
                    else -> 5000
                },
                easing = LinearEasing
            )
        ), label = "rotation"
    )

    val pulse by transition.animateFloat(
        initialValue = 0.8f, targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (state == JarvisState.SPEAKING) 200 else 2000),
            repeatMode = RepeatMode.Reverse
        ), label = "pulse"
    )

    Canvas(modifier = Modifier.size(180.dp)) {
        val center = Offset(size.width / 2, size.height / 2)
        val radius = (size.width / 2) * pulse
        val color = if (state == JarvisState.ERROR) WarningRed else NeonCyan

        drawCircle(color = color.copy(alpha = 0.15f), radius = radius, center = center)

        drawArc(
            color = color,
            startAngle = rotation,
            sweepAngle = if (state == JarvisState.LISTENING) 320f else 270f,
            useCenter = false,
            style = Stroke(width = 6.dp.toPx())
        )
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (message.isFromBoss) Alignment.End else Alignment.Start
    ) {
        Text(
            text = if (message.isFromBoss) "BOSS" else "JARVIS",
            color = if (message.isFromBoss) Color.LightGray else NeonCyan,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )

        Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (message.isFromBoss) Color(0xFF1E293B) else GlassPanel,
            border = if (!message.isFromBoss) BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.4f)) else null
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(text = message.text, color = Color.White, fontSize = 14.sp)

                if (message.actionSummary != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = message.actionSummary,
                        color = if (message.actionSummary.contains("\u2717")) WarningRed else NeonCyan,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

/**
 * Text-entry input row. Wire a SpeechRecognizer-backed mic button here to route
 * transcribed Hinglish audio into the same onQuerySubmitted callback.
 */
@Composable
fun MicrophoneInput(onQuerySubmitted: (String) -> Unit) {
    var text by remember { mutableStateOf("") }

    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.weight(1f),
            placeholder = { Text("Boss, kuch bhi poocho...", color = Color.Gray) }
        )
        Spacer(modifier = Modifier.width(8.dp))
        IconButton(onClick = {
            if (text.isNotBlank()) {
                onQuerySubmitted(text)
                text = ""
            }
        }) {
            Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = NeonCyan)
        }
    }
}
