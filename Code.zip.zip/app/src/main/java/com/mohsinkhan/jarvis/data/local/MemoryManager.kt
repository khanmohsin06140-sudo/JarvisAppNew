package com.mohsinkhan.jarvis.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

val Context.dataStore by preferencesDataStore(name = "jarvis_memory_core")

class MemoryManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        val BOSS_NAME_KEY = stringPreferencesKey("boss_name")
        val PREFERRED_LANGUAGE_KEY = stringPreferencesKey("preferred_language")
        val HAS_COMPLETED_ONBOARDING = booleanPreferencesKey("has_completed_onboarding")
    }

    val bossNameFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[BOSS_NAME_KEY] ?: "Mohsin Khan"
    }

    suspend fun savePreference(key: androidx.datastore.preferences.core.Preferences.Key<String>, value: String) {
        context.dataStore.edit { preferences ->
            preferences[key] = value
        }
    }

    suspend fun clearMemory() {
        context.dataStore.edit { preferences ->
            preferences.clear()
        }
    }
}
