/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: { extend: { colors: { matte: "#0a0a0a", charcoal: "#141414", gold: "#D4AF37" } } },
  plugins: []
};