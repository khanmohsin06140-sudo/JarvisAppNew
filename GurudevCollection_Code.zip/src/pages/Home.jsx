import { useEffect, useState } from "react";
import Hero from "../components/Hero";
import Catalog from "../components/Catalog";
import Footer from "../components/Footer";
import { fetchProducts } from "../lib/products";

export default function Home() {
  const [products, setProducts] = useState([]);
  const [error, setError] = useState("");
  useEffect(() => { fetchProducts().then(setProducts).catch(e => setError(e.message || "Unable to load products.")); }, []);
  return <><Hero/>{error ? <div className="px-5 py-20 text-center text-red-300">{error}</div> : <Catalog products={products}/>}<Footer/></>;
}