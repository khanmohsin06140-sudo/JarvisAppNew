import { ArrowDown, Sparkles } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-end overflow-hidden">
      <img
        src="https://images.unsplash.com/photo-1490578474895-699cd4e2cf59?auto=format&fit=crop&w=2200&q=90"
        alt="Gurudev Collection luxury fashion"
        className="absolute inset-0 h-full w-full object-cover object-center"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-black/55 to-black/20" />
      <div className="relative z-10 w-full px-5 pb-16 md:px-12 md:pb-20">
        <div className="max-w-4xl">
          <div className="mb-5 flex items-center gap-2 text-[#D4AF37] text-sm tracking-[0.3em] uppercase"><Sparkles size={16}/> Aurangabad • Maharashtra</div>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-semibold tracking-tight">Gurudev Collection</h1>
          <p className="mt-5 text-lg md:text-2xl text-gray-200">Premium Style & Modern Fits</p>
          <button onClick={() => document.getElementById("collection")?.scrollIntoView()} className="mt-8 inline-flex items-center gap-3 rounded-full bg-[#D4AF37] px-7 py-4 font-semibold text-black transition-all duration-300 hover:scale-105">
            Shop Collection <ArrowDown size={18}/>
          </button>
        </div>
      </div>
    </section>
  );
}