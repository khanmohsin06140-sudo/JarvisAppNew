import { useMemo, useState } from "react";
import ProductCard from "./ProductCard";
import ProductModal from "./ProductModal";

export default function Catalog({ products }) {
  const [category, setCategory] = useState("All");
  const [sort, setSort] = useState("new");
  const [selected, setSelected] = useState(null);
  const categories = ["All", ...new Set(products.map(p => p.category))];
  const filtered = useMemo(() => [...products.filter(p => category==="All" || p.category===category)].sort((a,b) => sort==="low" ? a.price-b.price : sort==="high" ? b.price-a.price : new Date(b.created_at)-new Date(a.created_at)), [products, category, sort]);
  return <section id="collection" className="px-5 py-20 md:px-12">
    <div className="mx-auto max-w-7xl">
      <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
        <div><div className="text-sm uppercase tracking-[0.3em] text-[#D4AF37]">The Collection</div><h2 className="mt-2 text-4xl font-semibold">Curated for distinction.</h2></div>
        <div className="flex flex-wrap gap-2">{categories.map(c => <button key={c} onClick={() => setCategory(c)} className={`rounded-full border px-4 py-2 text-sm ${category===c ? "border-[#D4AF37] bg-[#D4AF37] text-black" : "border-white/10 text-gray-400"}`}>{c}</button>)}<select value={sort} onChange={e=>setSort(e.target.value)} className="rounded-full border border-white/10 bg-[#141414] px-4 py-2 text-sm text-gray-300 outline-none"><option value="new">New Arrivals</option><option value="low">Price: Low to High</option><option value="high">Price: High to Low</option></select></div>
      </div>
      <div className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-5 lg:grid-cols-4">{filtered.map(p => <ProductCard key={p.id} product={p} onOpen={setSelected}/>)}</div>
    </div>
    {selected && <ProductModal product={selected} onClose={() => setSelected(null)}/>}
  </section>;
}