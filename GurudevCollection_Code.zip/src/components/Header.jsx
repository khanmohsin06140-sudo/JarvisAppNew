import { Link } from "react-router-dom";
import { Crown } from "lucide-react";

export default function Header() {
  return <header className="fixed top-0 left-0 right-0 z-40 bg-[#0a0a0a]/70 backdrop-blur-xl border-b border-white/5">
    <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 md:px-8">
      <a href="/" className="flex items-center gap-2 font-semibold tracking-wide"><Crown size={19} className="text-[#D4AF37]"/> GURUDEV</a>
      <Link to="/admin" className="text-xs uppercase tracking-[0.2em] text-gray-400 hover:text-white transition">Admin</Link>
    </div>
  </header>;
}