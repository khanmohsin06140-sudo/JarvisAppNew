import { useState } from "react";
import { X, MessageCircle, Check } from "lucide-react";
import { orderViaWhatsApp } from "../lib/whatsapp";

export default function ProductModal({ product, onClose }) {
  const [size, setSize] = useState(product.sizes?.[0] || "M");
  return <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 p-4 backdrop-blur-md" onClick={onClose}>
    <div className="mx-auto mt-8 grid max-w-5xl overflow-hidden rounded-3xl bg-[#141414] md:grid-cols-2" onClick={e => e.stopPropagation()}>
      <div className="relative aspect-square md:aspect-auto"><img src={product.image_url} alt={product.title} className="h-full w-full object-cover"/><button onClick={onClose} className="absolute right-3 top-3 rounded-full bg-black/70 p-3"><X size={20}/></button></div>
      <div className="p-6 md:p-9">
        <div className="text-xs uppercase tracking-[0.2em] text-[#D4AF37]">{product.category}</div>
        <h2 className="mt-2 text-3xl font-semibold">{product.title}</h2>
        <p className="mt-3 text-2xl font-semibold">₹{product.price.toLocaleString("en-IN")}</p>
        <p className="mt-6 leading-7 text-gray-400">{product.description}</p>
        <div className="mt-7"><div className="mb-3 text-sm font-medium">Select Size</div><div className="flex flex-wrap gap-2">{product.sizes?.map(s => <button key={s} onClick={() => setSize(s)} className={`rounded-full border px-5 py-2 ${size===s ? "border-[#D4AF37] bg-[#D4AF37] text-black" : "border-white/10 text-gray-300"}`}>{size===s && <Check size={14} className="mr-1 inline"/>}{s}</button>)}</div></div>
        <button onClick={() => orderViaWhatsApp(product, size)} className="mt-8 flex w-full items-center justify-center gap-2 rounded-xl bg-[#D4AF37] px-5 py-4 font-semibold text-black transition hover:scale-[1.02]"><MessageCircle size={19}/> Order via WhatsApp</button>
        <p className="mt-3 text-center text-xs text-gray-500">Personalized concierge ordering • Availability confirmed on WhatsApp</p>
      </div>
    </div>
  </div>;
}