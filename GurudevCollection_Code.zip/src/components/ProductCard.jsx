import { Tag } from "lucide-react";

const money = n => new Intl.NumberFormat("en-IN", { style:"currency", currency:"INR", maximumFractionDigits:0 }).format(n);

export default function ProductCard({ product, onOpen }) {
  const discount = product.mrp && product.mrp > product.price ? Math.round((1 - product.price / product.mrp) * 100) : 0;
  return <article onClick={() => onOpen(product)} className="group cursor-pointer overflow-hidden rounded-2xl bg-[#141414] border border-white/5 transition-all duration-300 hover:-translate-y-1 hover:border-[#D4AF37]/30">
    <div className="relative aspect-[4/5] overflow-hidden">
      {product.video_url ? <video src={product.video_url} autoPlay loop muted playsInline preload="metadata" className="h-full w-full object-cover transition duration-500 group-hover:scale-105" /> :
      <img src={product.image_url} alt={product.title} loading="lazy" className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />}
      {discount > 0 && <span className="absolute left-3 top-3 rounded-full bg-[#D4AF37] px-3 py-1 text-xs font-bold text-black"><Tag size={12} className="inline mr-1"/>{discount}% OFF</span>}
    </div>
    <div className="p-4">
      <div className="text-xs uppercase tracking-[0.18em] text-gray-500">{product.category}</div>
      <h3 className="mt-1 line-clamp-1 font-medium">{product.title}</h3>
      <div className="mt-2 flex items-center gap-2"><span className="text-lg font-semibold">{money(product.price)}</span>{product.mrp && <del className="text-sm text-gray-500">{money(product.mrp)}</del>}</div>
      <div className="mt-3 flex flex-wrap gap-1">{product.sizes?.map(s => <span key={s} className="rounded-full border border-white/10 px-2 py-1 text-[10px] text-gray-400">{s}</span>)}</div>
    </div>
  </article>;
}