import { MapPin, Phone, Clock, Instagram } from "lucide-react";

export default function Footer() {
  return <footer className="border-t border-white/5 bg-[#0a0a0a] px-5 py-14 md:px-12">
    <div className="mx-auto grid max-w-7xl gap-10 md:grid-cols-3">
      <div><h3 className="text-xl font-semibold">Gurudev Collection</h3><p className="mt-3 text-gray-500">Premium Style & Modern Fits</p></div>
      <div className="space-y-4 text-sm text-gray-400"><div className="flex gap-3"><MapPin className="text-[#D4AF37]" size={18}/> Aurangabad, Maharashtra</div><div className="flex gap-3"><Clock className="text-[#D4AF37]" size={18}/> Mon–Sun • 10:00 AM – 9:00 PM</div><a href="tel:+919999999999" className="flex gap-3 hover:text-white"><Phone className="text-[#D4AF37]" size={18}/> Call Store</a></div>
      <div className="flex gap-3"><a href="#" aria-label="Instagram" className="rounded-full border border-white/10 p-3"><Instagram size={18}/></a></div>
    </div>
    <div className="mx-auto mt-10 max-w-7xl border-t border-white/5 pt-6 text-xs text-gray-600">© {new Date().getFullYear()} Gurudev Collection — Aurangabad. All rights reserved.</div>
  </footer>;
}