# Gurudev Collection

Luxury e-commerce storefront for Gurudev Collection, Aurangabad, Maharashtra.

## Stack
- React + Vite
- Tailwind CSS
- Supabase-ready data layer
- React Router
- Lucide React
- WhatsApp conversational commerce

## Run
```bash
npm install
npm run dev
```

## Production build
```bash
npm run build
```

## Environment
Copy `.env.example` to `.env` and set the Supabase URL/key. The frontend falls back to local demo data if Supabase is not configured.

## GitHub/Vercel
The archive root intentionally contains `package.json`, `vite.config.js`, `index.html`, and `src/` directly. There is no extra parent project folder, so it can be extracted directly into a repository root.
