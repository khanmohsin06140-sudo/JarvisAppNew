create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null,
  price numeric not null check (price >= 0),
  mrp numeric null check (mrp is null or mrp >= 0),
  sizes text[] not null default '{}',
  description text null,
  image_url text not null,
  video_url text null,
  in_stock boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;
create policy "Public can read products" on public.products for select using (true);
create policy "Authenticated admins can insert products" on public.products for insert to authenticated with check (true);
create policy "Authenticated admins can update products" on public.products for update to authenticated using (true) with check (true);
create policy "Authenticated admins can delete products" on public.products for delete to authenticated using (true);

insert into storage.buckets (id, name, public) values ('product-media','product-media',true)
on conflict (id) do update set public = true;

create policy "Allow public read product media" on storage.objects
for select using (bucket_id = 'product-media');

create policy "Authenticated admins can upload product media" on storage.objects
for insert to authenticated with check (bucket_id = 'product-media');

create policy "Authenticated admins can update product media" on storage.objects
for update to authenticated using (bucket_id = 'product-media') with check (bucket_id = 'product-media');

create policy "Authenticated admins can delete product media" on storage.objects
for delete to authenticated using (bucket_id = 'product-media');